import svgPaths from "./svg-vgf3jh0d5e";
import imgAb6AXuDpZcd3ZS15Kr66C8IjbrbBlnNeZPpo1LcNIeXQjCGqyNgml9FAr6Bcg9Aax93KISw8WgrB9XICeGytu7U0CdFkLw1VdInUoo0SppopxoItVMgwscrLeXo2CDBlGVkQkMlw8VGu8DoBNgdH7V9Zxk72RQv54PebR4MAtp8NvVt4HLJuTp70EHpwuj1TlHiQqPmbip82D5LX7TTfdaZwZh5P8JCaefQzvHwIXwQg2Gm3Cw9J3M7Tqlln4E2Zd5I9U0DqS2Qy from "figma:asset/3228d90d49365c397d483c30bcb5b40183be47b3.png";
import imgAb6AXuAkF3E40IeKenxTx1VAoMs0VsNuDUteD38OzmXw0FXFPgfftobWrAyBJqxT7TbwtBty8B578AQOclH5MgpCl5R3YhilPdcHo9T7ChkzLuh3Fi5Wu3B3507SOirPYdaEvnRbHqTlGYn1H7GxZphq1Ksa7AsRtgljgd7SBgTqGSWRgA1UOjdFqmU4XzICmdKUfdBuhGgZDw1PiaHaVTaxdoD38KlnpHqVRk1Ssxl3DE4NsI3TlIe6F3Xj5N7L9NZftBn4FtQ from "figma:asset/e2037576d31b9f8a628df2dec8dd7b1e181bd6a7.png";
import imgAdBb0Ug7Pwj1Md8RuuHnTdDxUzi4TbI74Gxc5XDsQcr75PmS5Rg1Uufj7U1C6K9UEjKd0BLuiPoQjaBbkMfwjI6ZVBsgL80IuPiR39VRhEfBciu7QiShmfQeHEd5ZeTGyV7LdxYnIj7VMg1FaAlxmSxHnFyh1HpcUly4BsgleZsqn37AOie0Gap080GrIvcX0AxpoyG45UTfoNdEhSgSlGhXCpp9XIysoVzsFwFskQCajEk8Cc8Eb22LYbA from "figma:asset/69d6a381bddeec8a41c0b5d5996c77ba359d2a77.png";
import imgAb6AXuC7WrDBiUWiA4IioVoyYjlc60LUDGysXjnULWrdNaNg3DAgKycJXkKboLMrvXTiHj1ERvHuQQzhoUNlMu0RVdlKFf1Zxl9W4Lgw631Pzxrdn7DkRDoXDmLaXaItKjscqwYaFp4AS3Bn1T0Q2YHzeliaItfYSJoLR7TdPkj57GTfOsAiwVlkkQc5X8UkfXvhFiGdUuAfBIkLce7Ji9D3A0Zhu9U1JGqAzdpt8CqLlalNyMjOc0WJcCmJNiR6Y4BIiuxHl0 from "figma:asset/415d81eb34d5b6aa21bbb15dac76d8ff7d7f06a2.png";
import imgAb6AXuDpOxsOoBdObKxnoCreLgMxdKf0KwRp4XNkgecWAbp96XcG3SeMrbkzcWcy0TYvl0Vcl9Qc3CJaGmjEcj0DnDixN2QHtBmV2SFeQv1Fggx7HnR40CMwRMuGurLvHwuz91GAlw34HygrQoTEquMkhm7BYoJtIaCtRybbqdSJTpN5FBctACrPwTmpiJ8GSoIuxKNd0OKlH1JtyJzuzFoJ4XCw6ZKXbn5W9AM9QA1Yf4MyyUp2WdCuTn2AUxgBDhOoWx9Gk from "figma:asset/bd1bed4caa6af983753e55a87f642404740d8ff3.png";

function Container1() {
  return (
    <div className="h-[30px] relative shrink-0 w-full" data-name="Container">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 373.333 30">
        <g id="Container">
          <path d={svgPaths.p327b5f80} fill="var(--fill-0, #FFD308)" id="Icon" />
        </g>
      </svg>
    </div>
  );
}

function Heading2() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Heading 3">
      <div className="flex flex-col font-['Manrope:Bold',sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[24px] text-white tracking-[-0.6px] w-full">
        <p className="leading-[32px]">Urban Speed</p>
      </div>
    </div>
  );
}

function Container2() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center leading-[0] not-italic relative shrink-0 text-[#adaaaa] text-[16px] w-full">
        <p className="leading-[26px] mb-0">Madrid never stops, and neither do we.</p>
        <p className="leading-[26px] mb-0">Optimized route tracking ensures you bypass the</p>
        <p className="leading-[26px]">Gran Vía congestion with surgical precision.</p>
      </div>
    </div>
  );
}

function Feature() {
  return (
    <div className="col-1 content-stretch flex flex-col gap-[24px] items-start justify-self-stretch relative row-1 self-start shrink-0" data-name="Feature 1">
      <Container1 />
      <Heading2 />
      <Container2 />
      <div className="bg-[#ffd308] h-[2px] shrink-0 w-[48px]" data-name="Horizontal Divider" />
    </div>
  );
}

function Container3() {
  return (
    <div className="h-[30px] relative shrink-0 w-full" data-name="Container">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 373.333 30">
        <g id="Container">
          <path d={svgPaths.p209a7840} fill="var(--fill-0, #FFD308)" id="Icon" />
        </g>
      </svg>
    </div>
  );
}

function Heading3() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Heading 3">
      <div className="flex flex-col font-['Manrope:Bold',sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[24px] text-white tracking-[-0.6px] w-full">
        <p className="leading-[32px]">Elite Safety</p>
      </div>
    </div>
  );
}

function Container4() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center leading-[0] not-italic relative shrink-0 text-[#adaaaa] text-[16px] w-full">
        <p className="leading-[26px] mb-0">Our drivers are more than chauffeurs; they are</p>
        <p className="leading-[26px] mb-0">certified safety professionals. Luxury is nothing</p>
        <p className="leading-[26px]">without total peace of mind.</p>
      </div>
    </div>
  );
}

function Feature1() {
  return (
    <div className="col-2 content-stretch flex flex-col gap-[24px] items-start justify-self-stretch relative row-1 self-start shrink-0" data-name="Feature 2">
      <Container3 />
      <Heading3 />
      <Container4 />
      <div className="bg-[#ffd308] h-[2px] shrink-0 w-[48px]" data-name="Horizontal Divider" />
    </div>
  );
}

function Container5() {
  return (
    <div className="h-[28.5px] relative shrink-0 w-full" data-name="Container">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 373.333 28.5">
        <g id="Container">
          <path d={svgPaths.p388a7810} fill="var(--fill-0, #FFD308)" id="Icon" />
        </g>
      </svg>
    </div>
  );
}

function Heading4() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Heading 3">
      <div className="flex flex-col font-['Manrope:Bold',sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[24px] text-white tracking-[-0.6px] w-full">
        <p className="leading-[32px]">Local Mastery</p>
      </div>
    </div>
  );
}

function Container6() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center leading-[0] not-italic relative shrink-0 text-[#adaaaa] text-[16px] w-full">
        <p className="leading-[26px] mb-0">From hidden shortcuts in Malasaña to VIP access</p>
        <p className="leading-[26px] mb-0">at the Santiago Bernabéu, our knowledge of the</p>
        <p className="leading-[26px]">capital is unmatched.</p>
      </div>
    </div>
  );
}

function Feature2() {
  return (
    <div className="col-3 content-stretch flex flex-col gap-[24px] items-start justify-self-stretch relative row-1 self-start shrink-0" data-name="Feature 3">
      <Container5 />
      <Heading4 />
      <Container6 />
      <div className="bg-[#ffd308] h-[2px] shrink-0 w-[48px]" data-name="Horizontal Divider" />
    </div>
  );
}

function Container() {
  return (
    <div className="gap-x-[48px] gap-y-[48px] grid grid-cols-[repeat(3,minmax(0,1fr))] grid-rows-[_224px] max-w-[1440px] relative shrink-0 w-full" data-name="Container">
      <Feature />
      <Feature1 />
      <Feature2 />
    </div>
  );
}

function SectionKeyFeaturesTonalLayering() {
  return (
    <div className="absolute bg-[#131313] content-stretch flex flex-col items-start left-0 px-[32px] py-[128px] right-0 top-[3821px]" data-name="Section - Key Features (Tonal Layering)">
      <Container />
    </div>
  );
}

function Container9() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Manrope:Bold',sans-serif] font-bold h-[28px] justify-center leading-[0] relative shrink-0 text-[#ffd308] text-[20px] w-[97.08px]">
        <p className="leading-[28px]">Madrileño</p>
      </div>
    </div>
  );
}

function Container10() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#737373] text-[12px] tracking-[1.2px] uppercase w-[432.22px]">
        <p className="leading-[16px]">© 2024 MADRILEÑO. URBAN PULSE MOBILITY. MADRID, SPAIN.</p>
      </div>
    </div>
  );
}

function Container8() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0 w-[432.22px]" data-name="Container">
      <Container9 />
      <Container10 />
    </div>
  );
}

function Link() {
  return (
    <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0" data-name="Link">
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#737373] text-[12px] tracking-[1.2px] uppercase w-[47.98px]">
        <p className="leading-[16px]">ABOUT</p>
      </div>
    </div>
  );
}

function Link1() {
  return (
    <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0" data-name="Link">
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#737373] text-[12px] tracking-[1.2px] uppercase w-[42.05px]">
        <p className="leading-[16px]">FLEET</p>
      </div>
    </div>
  );
}

function Link2() {
  return (
    <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0" data-name="Link">
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#737373] text-[12px] tracking-[1.2px] uppercase w-[53.61px]">
        <p className="leading-[16px]">SAFETY</p>
      </div>
    </div>
  );
}

function Link3() {
  return (
    <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0" data-name="Link">
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#737373] text-[12px] tracking-[1.2px] uppercase w-[35.39px]">
        <p className="leading-[16px]">HELP</p>
      </div>
    </div>
  );
}

function Link4() {
  return (
    <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0" data-name="Link">
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#737373] text-[12px] tracking-[1.2px] uppercase w-[47.23px]">
        <p className="leading-[16px]">TERMS</p>
      </div>
    </div>
  );
}

function Link5() {
  return (
    <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0" data-name="Link">
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#737373] text-[12px] tracking-[1.2px] uppercase w-[59.25px]">
        <p className="leading-[16px]">PRIVACY</p>
      </div>
    </div>
  );
}

function Container11() {
  return (
    <div className="content-stretch flex gap-[32px] h-[16px] items-start relative shrink-0" data-name="Container">
      <Link />
      <Link1 />
      <Link2 />
      <Link3 />
      <Link4 />
      <Link5 />
    </div>
  );
}

function Container13() {
  return (
    <div className="h-[11.667px] relative shrink-0 w-[10.5px]" data-name="Container">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.5 11.6667">
        <g id="Container">
          <path d={svgPaths.p313c6040} fill="var(--fill-0, #737373)" id="Icon" />
        </g>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div className="content-stretch flex items-center justify-center p-px relative rounded-[12px] shrink-0 size-[40px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#404040] border-solid inset-0 pointer-events-none rounded-[12px]" />
      <Container13 />
    </div>
  );
}

function Container14() {
  return (
    <div className="relative shrink-0 size-[11.667px]" data-name="Container">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.6667 11.6667">
        <g id="Container">
          <path d={svgPaths.p3c4dd880} fill="var(--fill-0, #737373)" id="Icon" />
        </g>
      </svg>
    </div>
  );
}

function Button1() {
  return (
    <div className="content-stretch flex items-center justify-center p-px relative rounded-[12px] shrink-0 size-[40px]" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[#404040] border-solid inset-0 pointer-events-none rounded-[12px]" />
      <Container14 />
    </div>
  );
}

function Container12() {
  return (
    <div className="content-stretch flex gap-[16px] items-start relative shrink-0" data-name="Container">
      <Button />
      <Button1 />
    </div>
  );
}

function Container7() {
  return (
    <div className="max-w-[1280px] relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center max-w-[inherit] size-full">
        <div className="content-stretch flex items-center justify-between max-w-[inherit] pl-[32px] pr-[32.02px] relative size-full">
          <Container8 />
          <Container11 />
          <Container12 />
        </div>
      </div>
    </div>
  );
}

function Footer() {
  return (
    <div className="absolute bg-[#131313] content-stretch flex flex-col items-start left-0 pb-[40px] pt-[80px] right-0 top-[6257px]" data-name="Footer">
      <Container7 />
    </div>
  );
}

function Heading() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Heading 1">
      <div className="flex flex-col font-['Manrope:ExtraBold',sans-serif] font-extrabold justify-center leading-[0] relative shrink-0 text-[72px] text-white tracking-[-3.6px] w-full">
        <p className="mb-0">
          <span className="leading-[72px]">{`THE `}</span>
          <span className="font-['Manrope:ExtraBold',sans-serif] font-extrabold leading-[72px] text-[#ffd308]">URBAN</span>
        </p>
        <p className="mb-0">
          <span className="font-['Manrope:ExtraBold',sans-serif] font-extrabold leading-[72px] text-[#ffd308]">PULSE</span>
          <span className="leading-[72px]">{` OF`}</span>
        </p>
        <p className="leading-[72px]">MADRID.</p>
      </div>
    </div>
  );
}

function Heading1Margin() {
  return (
    <div className="content-stretch flex flex-col items-start pb-[24px] relative shrink-0 w-full" data-name="Heading 1:margin">
      <Heading />
    </div>
  );
}

function Container15() {
  return (
    <div className="content-stretch flex flex-col items-start max-w-[512px] relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center leading-[0] not-italic relative shrink-0 text-[#adaaaa] text-[20px] w-full">
        <p className="leading-[28px] mb-0">Elite chauffeur service designed for the rhythm of the</p>
        <p className="leading-[28px] mb-0">city. Experience the precision of local mastery and</p>
        <p className="leading-[28px]">the comfort of a premier fleet.</p>
      </div>
    </div>
  );
}

function Margin() {
  return (
    <div className="content-stretch flex flex-col items-start max-w-[512px] pb-[40px] relative shrink-0 w-full" data-name="Margin">
      <Container15 />
    </div>
  );
}

function Container19() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-w-px overflow-clip relative" data-name="Container">
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center leading-[0] not-italic relative shrink-0 text-[#6b7280] text-[14px] w-full">
        <p className="leading-[normal]">Calle de Alcalá, 1</p>
      </div>
    </div>
  );
}

function Input() {
  return (
    <div className="bg-[#20201f] relative rounded-[4px] shrink-0 w-full" data-name="Input">
      <div className="flex flex-row justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex items-start justify-center pb-[14px] pl-[40px] pr-[12px] pt-[13px] relative size-full">
          <Container19 />
        </div>
      </div>
    </div>
  );
}

function Container20() {
  return (
    <div className="absolute bottom-[27.27%] content-stretch flex flex-col items-start left-[12px] top-[27.27%]" data-name="Container">
      <div className="h-[11.667px] relative shrink-0 w-[9.333px]" data-name="Icon">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.33333 11.6667">
          <path d={svgPaths.p3d8f00c0} fill="var(--fill-0, #FFE48B)" id="Icon" />
        </svg>
      </div>
    </div>
  );
}

function Container18() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <Input />
      <Container20 />
    </div>
  );
}

function Container17() {
  return (
    <div className="col-1 content-stretch flex flex-col gap-[4.5px] items-start justify-self-stretch relative row-1 self-start shrink-0" data-name="Container">
      <div className="flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#ffe48b] text-[10px] tracking-[1px] uppercase w-[83.05px]">
        <p className="leading-[15px]">PICKUP POINT</p>
      </div>
      <Container18 />
    </div>
  );
}

function Container23() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-w-px overflow-clip relative" data-name="Container">
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center leading-[0] not-italic relative shrink-0 text-[#6b7280] text-[14px] w-full">
        <p className="leading-[normal]">Adolfo Suárez Airport</p>
      </div>
    </div>
  );
}

function Input1() {
  return (
    <div className="bg-[#20201f] relative rounded-[4px] shrink-0 w-full" data-name="Input">
      <div className="flex flex-row justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex items-start justify-center pb-[14px] pl-[40px] pr-[12px] pt-[13px] relative size-full">
          <Container23 />
        </div>
      </div>
    </div>
  );
}

function Container24() {
  return (
    <div className="absolute bottom-[27.27%] content-stretch flex flex-col items-start left-[12px] top-[27.27%]" data-name="Container">
      <div className="h-[9.917px] relative shrink-0 w-[8.75px]" data-name="Icon">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8.75 9.91667">
          <path d={svgPaths.p88e5080} fill="var(--fill-0, #ADAAAA)" id="Icon" />
        </svg>
      </div>
    </div>
  );
}

function Container22() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <Input1 />
      <Container24 />
    </div>
  );
}

function Container21() {
  return (
    <div className="col-2 content-stretch flex flex-col gap-[4.5px] items-start justify-self-stretch relative row-1 self-start shrink-0" data-name="Container">
      <div className="flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#adaaaa] text-[10px] tracking-[1px] uppercase w-[78.73px]">
        <p className="leading-[15px]">DESTINATION</p>
      </div>
      <Container22 />
    </div>
  );
}

function Container16() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid gap-x-[16px] gap-y-[16px] grid grid-cols-[repeat(2,minmax(0,1fr))] grid-rows-[_63px] relative size-full">
        <Container17 />
        <Container21 />
      </div>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="content-stretch flex font-['Inter:Regular',sans-serif] font-normal gap-px items-start leading-[0] not-italic pl-px pr-[1.01px] relative self-stretch shrink-0 text-[14px] text-white" data-name="Paragraph">
      <div className="flex flex-col h-[20px] justify-center relative shrink-0 w-[24.53px]">
        <p className="leading-[20px]">mm</p>
      </div>
      <div className="flex flex-col h-[20px] justify-center relative shrink-0 w-[5.05px]">
        <p className="leading-[20px]">/</p>
      </div>
      <div className="flex flex-col h-[20px] justify-center relative shrink-0 w-[17.16px]">
        <p className="leading-[20px]">dd</p>
      </div>
      <div className="flex flex-col h-[20px] justify-center relative shrink-0 w-[5.05px]">
        <p className="leading-[20px]">/</p>
      </div>
      <div className="flex flex-col h-[20px] justify-center relative shrink-0 w-[31.48px]">
        <p className="leading-[20px]">yyyy</p>
      </div>
    </div>
  );
}

function Container28() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-[20px] items-start min-w-px overflow-clip relative" data-name="Container">
      <Paragraph />
    </div>
  );
}

function Svg() {
  return <div className="h-[13.125px] shrink-0 w-[14px]" data-name="SVG" />;
}

function ButtonMenu() {
  return (
    <div className="content-stretch flex flex-col items-start overflow-clip p-[2px] relative shrink-0 size-[18px]" data-name="Button menu">
      <Svg />
    </div>
  );
}

function Container27() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-center min-w-px relative" data-name="Container">
      <Container28 />
      <ButtonMenu />
    </div>
  );
}

function Input2() {
  return (
    <div className="bg-[#20201f] relative rounded-[4px] shrink-0 w-full" data-name="Input">
      <div className="flex flex-row justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex items-start justify-center px-[16px] py-[12px] relative size-full">
          <Container27 />
        </div>
      </div>
    </div>
  );
}

function Container26() {
  return (
    <div className="col-1 content-stretch flex flex-col gap-[4.5px] items-start justify-self-stretch pb-[0.69px] relative row-1 self-start shrink-0" data-name="Container">
      <div className="flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#adaaaa] text-[10px] tracking-[1px] uppercase w-[29.89px]">
        <p className="leading-[15px]">DATE</p>
      </div>
      <Input2 />
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="font-['Inter:Regular',sans-serif] font-normal leading-[0] not-italic relative self-stretch shrink-0 text-[14px] text-white w-[50.69px]" data-name="Paragraph">
      <div className="-translate-y-1/2 absolute flex flex-col h-[20px] justify-center left-px top-[9.5px] w-[12.89px]">
        <p className="leading-[20px]">--</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col h-[20px] justify-center left-[14.89px] top-[9.5px] w-[4.05px]">
        <p className="leading-[20px]">:</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col h-[20px] justify-center left-[19.94px] top-[9.5px] w-[12.89px]">
        <p className="leading-[20px]">--</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col h-[20px] justify-center left-[36.8px] top-[9.5px] w-[12.89px]">
        <p className="leading-[20px]">--</p>
      </div>
    </div>
  );
}

function Container31() {
  return (
    <div className="content-stretch flex flex-[1_0_0] h-[20px] items-start min-w-px overflow-clip relative" data-name="Container">
      <Paragraph1 />
    </div>
  );
}

function Svg1() {
  return <div className="shrink-0 size-[14.69px]" data-name="SVG" />;
}

function ButtonMenu1() {
  return (
    <div className="content-stretch flex flex-col items-start overflow-clip p-[3px] relative shrink-0 size-[20.69px]" data-name="Button menu">
      <Svg1 />
    </div>
  );
}

function ButtonMenuMargin() {
  return (
    <div className="content-stretch flex flex-col h-[20.69px] items-start pl-[8px] relative shrink-0 w-[28.69px]" data-name="Button menu:margin">
      <ButtonMenu1 />
    </div>
  );
}

function Container30() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-center min-w-px relative" data-name="Container">
      <Container31 />
      <ButtonMenuMargin />
    </div>
  );
}

function Input3() {
  return (
    <div className="bg-[#20201f] relative rounded-[4px] shrink-0 w-full" data-name="Input">
      <div className="flex flex-row justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex items-start justify-center px-[16px] py-[12px] relative size-full">
          <Container30 />
        </div>
      </div>
    </div>
  );
}

function Container29() {
  return (
    <div className="col-2 content-stretch flex flex-col gap-[4.5px] items-start justify-self-stretch relative row-1 self-start shrink-0" data-name="Container">
      <div className="flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#adaaaa] text-[10px] tracking-[1px] uppercase w-[28.66px]">
        <p className="leading-[15px]">TIME</p>
      </div>
      <Input3 />
    </div>
  );
}

function Container25() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid gap-x-[16px] gap-y-[16px] grid grid-cols-[repeat(2,minmax(0,1fr))] grid-rows-[_63.69px] pb-[7.99px] relative size-full">
        <Container26 />
        <Container29 />
      </div>
    </div>
  );
}

function Button2() {
  return (
    <div className="relative rounded-[4px] shrink-0 w-full" style={{ backgroundImage: "linear-gradient(135deg, rgb(255, 228, 139) 0%, rgb(255, 211, 8) 100%)" }} data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center py-[16px] relative size-full">
        <div className="flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[24px] justify-center leading-[0] not-italic relative shrink-0 text-[#5a4900] text-[16px] text-center tracking-[1.6px] uppercase w-[217.38px]">
          <p className="leading-[24px]">CONFIRM RIDE DETAILS</p>
        </div>
      </div>
    </div>
  );
}

function BookingFormFloatingGlassCard() {
  return (
    <div className="backdrop-blur-[10px] bg-[rgba(44,44,44,0.6)] max-w-[576px] relative rounded-[8px] shrink-0 w-full" data-name="Booking Form (Floating Glass Card)">
      <div aria-hidden="true" className="absolute border border-[rgba(255,255,255,0.05)] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="content-stretch flex flex-col gap-[16px] items-start max-w-[inherit] p-[33px] relative size-full">
        <Container16 />
        <Container25 />
        <Button2 />
      </div>
    </div>
  );
}

function TextContentSide() {
  return (
    <div className="flex-[1_0_0] min-w-px relative self-stretch" data-name="Text & Content Side">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center px-[64px] py-[48px] relative size-full">
          <Heading1Margin />
          <Margin />
          <BookingFormFloatingGlassCard />
        </div>
      </div>
    </div>
  );
}

function Ab6AXuDpZcd3ZS15Kr66C8IjbrbBlnNeZPpo1LcNIeXQjCGqyNgml9FAr6Bcg9Aax93KISw8WgrB9XICeGytu7U0CdFkLw1VdInUoo0SppopxoItVMgwscrLeXo2CDBlGVkQkMlw8VGu8DoBNgdH7V9Zxk72RQv54PebR4MAtp8NvVt4HLJuTp70EHpwuj1TlHiQqPmbip82D5LX7TTfdaZwZh5P8JCaefQzvHwIXwQg2Gm3Cw9J3M7Tqlln4E2Zd5I9U0DqS2Qy() {
  return (
    <div className="flex-[1_0_0] min-h-px relative w-full" data-name="AB6AXuDpZCD3_zS15KR66c8ijbrbBLNNe-Z_PPO1LcNIeXQjCGqyNGML9fAr6bcg9Aax93kISw8wgr_B9xI-CeGYTU7U0cdFKLw1vdInUoo0SPPOPXOItVMgwscrLeXO2cDBlGVkQkMLW8VGu8DoBNgdH7V9zxk72RQv54pebR4mATP8NvVT4H_lJUTp70EHpwuj-1tlHiQQPmbip82D5lX7tTfdaZwZH5p8JCaefQzvHwIXwQG2gm3CW9j3m7Tqlln4e2ZD5I9U0dqS2QY">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <img alt="" className="absolute h-full left-[-242.27%] max-w-none top-0 w-[584.53%]" src={imgAb6AXuDpZcd3ZS15Kr66C8IjbrbBlnNeZPpo1LcNIeXQjCGqyNgml9FAr6Bcg9Aax93KISw8WgrB9XICeGytu7U0CdFkLw1VdInUoo0SppopxoItVMgwscrLeXo2CDBlGVkQkMlw8VGu8DoBNgdH7V9Zxk72RQv54PebR4MAtp8NvVt4HLJuTp70EHpwuj1TlHiQqPmbip82D5LX7TTfdaZwZh5P8JCaefQzvHwIXwQg2Gm3Cw9J3M7Tqlln4E2Zd5I9U0DqS2Qy} />
      </div>
    </div>
  );
}

function ImageSideMadridUrbanSetting() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col h-[3741px] items-start justify-center min-w-px relative" data-name="Image Side (Madrid Urban Setting)">
      <Ab6AXuDpZcd3ZS15Kr66C8IjbrbBlnNeZPpo1LcNIeXQjCGqyNgml9FAr6Bcg9Aax93KISw8WgrB9XICeGytu7U0CdFkLw1VdInUoo0SppopxoItVMgwscrLeXo2CDBlGVkQkMlw8VGu8DoBNgdH7V9Zxk72RQv54PebR4MAtp8NvVt4HLJuTp70EHpwuj1TlHiQqPmbip82D5LX7TTfdaZwZh5P8JCaefQzvHwIXwQg2Gm3Cw9J3M7Tqlln4E2Zd5I9U0DqS2Qy />
      <div className="absolute bg-[rgba(0,0,0,0.4)] inset-0 mix-blend-multiply" data-name="Overlay" />
      <div className="absolute bg-gradient-to-t from-[#0e0e0e] inset-0 to-[rgba(14,14,14,0.2)] via-1/2 via-[rgba(14,14,14,0)]" data-name="Gradient" />
      <div className="absolute bg-gradient-to-r from-[#0e0e0e] inset-0 to-[rgba(14,14,14,0)] via-1/2 via-[rgba(14,14,14,0)]" data-name="Gradient" />
    </div>
  );
}

function MainHeroSectionWithAsymmetricLayout() {
  return (
    <div className="absolute content-stretch flex items-start left-0 min-h-[3741px] pt-[80px] right-0 top-0" data-name="Main - Hero Section with Asymmetric Layout">
      <TextContentSide />
      <ImageSideMadridUrbanSetting />
    </div>
  );
}

function Heading1() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Heading 2">
      <div className="flex flex-col font-['Manrope:ExtraBold',sans-serif] font-extrabold justify-center leading-[0] relative shrink-0 text-[60px] text-white tracking-[-3px] uppercase w-full">
        <p>
          <span className="leading-[60px]">{`GET IN `}</span>
          <span className="font-['Manrope:ExtraBold',sans-serif] font-extrabold leading-[60px] text-[#ffe48b]">TOUCH</span>
          <span className="leading-[60px]">.</span>
        </p>
      </div>
    </div>
  );
}

function Container34() {
  return (
    <div className="content-stretch flex flex-col items-start max-w-[448px] relative shrink-0 w-[448px]" data-name="Container">
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[88px] justify-center leading-[0] not-italic relative shrink-0 text-[#adaaaa] text-[18px] w-[443.58px]">
        <p className="leading-[29.25px] mb-0">Whether you have a specific request for a corporate</p>
        <p className="leading-[29.25px] mb-0">event or need a long-distance transfer, our team is</p>
        <p className="leading-[29.25px]">ready to coordinate your journey.</p>
      </div>
    </div>
  );
}

function Container37() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="Container">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Container">
          <path d={svgPaths.p143e1930} fill="var(--fill-0, #FFE48B)" id="Icon" />
        </g>
      </svg>
    </div>
  );
}

function Container38() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[24px] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-white w-[129.69px]">
        <p className="leading-[24px]">+34 912 345 678</p>
      </div>
    </div>
  );
}

function Container36() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0 w-full" data-name="Container">
      <Container37 />
      <Container38 />
    </div>
  );
}

function Container40() {
  return (
    <div className="h-[16px] relative shrink-0 w-[20px]" data-name="Container">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 16">
        <g id="Container">
          <path d={svgPaths.p13e73800} fill="var(--fill-0, #FFE48B)" id="Icon" />
        </g>
      </svg>
    </div>
  );
}

function Container41() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[24px] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-white w-[206.31px]">
        <p className="leading-[24px]">concierge@madrileno.com</p>
      </div>
    </div>
  );
}

function Container39() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0 w-full" data-name="Container">
      <Container40 />
      <Container41 />
    </div>
  );
}

function Container43() {
  return (
    <div className="h-[20px] relative shrink-0 w-[16px]" data-name="Container">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 20">
        <g id="Container">
          <path d={svgPaths.p1869180} fill="var(--fill-0, #FFE48B)" id="Icon" />
        </g>
      </svg>
    </div>
  );
}

function Container44() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[24px] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-white w-[273.05px]">
        <p className="leading-[24px]">Paseo de la Castellana, 259, Madrid</p>
      </div>
    </div>
  );
}

function Container42() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0 w-full" data-name="Container">
      <Container43 />
      <Container44 />
    </div>
  );
}

function Container35() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start pt-[8px] relative shrink-0 w-full" data-name="Container">
      <Container36 />
      <Container39 />
      <Container42 />
    </div>
  );
}

function Container33() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col gap-[24px] items-start min-w-px relative" data-name="Container">
      <Heading1 />
      <Container34 />
      <Container35 />
    </div>
  );
}

function Container47() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-w-px overflow-clip relative" data-name="Container">
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center leading-[0] not-italic relative shrink-0 text-[#525252] text-[14px] w-full">
        <p className="leading-[normal]">Juan Pérez</p>
      </div>
    </div>
  );
}

function Input4() {
  return (
    <div className="bg-[#20201f] relative rounded-[4px] shrink-0 w-full" data-name="Input">
      <div className="flex flex-row justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex items-start justify-center pb-[18px] pt-[17px] px-[16px] relative size-full">
          <Container47 />
        </div>
      </div>
    </div>
  );
}

function Container46() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[4.5px] items-start relative size-full">
        <div className="flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#adaaaa] text-[10px] tracking-[1px] uppercase w-[66.22px]">
          <p className="leading-[15px]">FULL NAME</p>
        </div>
        <Input4 />
      </div>
    </div>
  );
}

function Container49() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-w-px overflow-clip relative" data-name="Container">
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center leading-[0] not-italic relative shrink-0 text-[#525252] text-[14px] w-full">
        <p className="leading-[normal]">juan.perez@example.com</p>
      </div>
    </div>
  );
}

function Input5() {
  return (
    <div className="bg-[#20201f] relative rounded-[4px] shrink-0 w-full" data-name="Input">
      <div className="flex flex-row justify-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex items-start justify-center pb-[18px] pt-[17px] px-[16px] relative size-full">
          <Container49 />
        </div>
      </div>
    </div>
  );
}

function Container48() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[4.5px] items-start relative size-full">
        <div className="flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#adaaaa] text-[10px] tracking-[1px] uppercase w-[93.81px]">
          <p className="leading-[15px]">EMAIL ADDRESS</p>
        </div>
        <Input5 />
      </div>
    </div>
  );
}

function Container51() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-w-px relative" data-name="Container">
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center leading-[0] not-italic relative shrink-0 text-[#525252] text-[14px] w-full">
        <p className="leading-[20px]">Tell us about your requirements...</p>
      </div>
    </div>
  );
}

function Textarea() {
  return (
    <div className="bg-[#20201f] min-h-[120px] relative rounded-[4px] shrink-0 w-full" data-name="Textarea">
      <div className="flex flex-row justify-center min-h-[inherit] overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex items-start justify-center min-h-[inherit] pb-[84px] pt-[16px] px-[16px] relative size-full">
          <Container51 />
        </div>
      </div>
    </div>
  );
}

function Container50() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[4.5px] items-start relative size-full">
        <div className="flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#adaaaa] text-[10px] tracking-[1px] uppercase w-[55.63px]">
          <p className="leading-[15px]">MESSAGE</p>
        </div>
        <Textarea />
      </div>
    </div>
  );
}

function Button3() {
  return (
    <div className="relative rounded-[4px] shrink-0 w-full" style={{ backgroundImage: "linear-gradient(135deg, rgb(255, 228, 139) 0%, rgb(255, 211, 8) 100%)" }} data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center py-[16px] relative size-full">
        <div className="absolute bg-[rgba(255,255,255,0)] inset-0 rounded-[4px] shadow-[0px_10px_15px_-3px_rgba(255,228,139,0.1),0px_4px_6px_-4px_rgba(255,228,139,0.1)]" data-name="Button:shadow" />
        <div className="flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[24px] justify-center leading-[0] not-italic relative shrink-0 text-[#443700] text-[16px] text-center tracking-[1.6px] uppercase w-[144.81px]">
          <p className="leading-[24px]">SEND MESSAGE</p>
        </div>
      </div>
    </div>
  );
}

function Form() {
  return (
    <div className="backdrop-blur-[10px] bg-[rgba(44,44,44,0.6)] relative rounded-[8px] shrink-0 w-full" data-name="Form">
      <div aria-hidden="true" className="absolute border border-[rgba(255,255,255,0.05)] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="content-stretch flex flex-col gap-[24px] items-start p-[41px] relative size-full">
        <Container46 />
        <Container48 />
        <Container50 />
        <Button3 />
      </div>
    </div>
  );
}

function Container45() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-w-px pb-[16px] relative" data-name="Container">
      <Form />
    </div>
  );
}

function Container32() {
  return (
    <div className="content-stretch flex gap-[80px] items-center max-w-[1440px] relative shrink-0 w-full" data-name="Container">
      <Container33 />
      <Container45 />
    </div>
  );
}

function ContactFormSection() {
  return (
    <div className="absolute bg-[#0e0e0e] content-stretch flex flex-col items-start left-0 overflow-clip px-[32px] py-[128px] right-0 top-[4301px]" data-name="Contact Form Section">
      <Container32 />
    </div>
  );
}

function Heading5() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Heading 2">
      <div className="flex flex-col font-['Manrope:ExtraBold',sans-serif] font-extrabold justify-center leading-[0] relative shrink-0 text-[36px] text-white tracking-[-1.8px] uppercase w-full">
        <p className="leading-[40px]">THE FLEET</p>
      </div>
    </div>
  );
}

function Container55() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
      <div className="flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#adaaaa] text-[12px] tracking-[3.6px] uppercase w-[210.75px]">
        <p className="leading-[16px]">SELECTED EXCELLENCE</p>
      </div>
    </div>
  );
}

function Container54() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0 w-full" data-name="Container">
      <div className="bg-[#ffe48b] h-px shrink-0 w-[96px]" data-name="Horizontal Divider" />
      <Container55 />
    </div>
  );
}

function Container53() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0 w-full" data-name="Container">
      <Heading5 />
      <Container54 />
    </div>
  );
}

function Ab6AXuAkF3E40IeKenxTx1VAoMs0VsNuDUteD38OzmXw0FXFPgfftobWrAyBJqxT7TbwtBty8B578AQOclH5MgpCl5R3YhilPdcHo9T7ChkzLuh3Fi5Wu3B3507SOirPYdaEvnRbHqTlGYn1H7GxZphq1Ksa7AsRtgljgd7SBgTqGSWRgA1UOjdFqmU4XzICmdKUfdBuhGgZDw1PiaHaVTaxdoD38KlnpHqVRk1Ssxl3DE4NsI3TlIe6F3Xj5N7L9NZftBn4FtQ() {
  return (
    <div className="flex-[1_0_0] min-h-px relative w-full" data-name="AB6AXuAkF3-E40ie_kenxTX1VAoMs0vsNuDUteD38ozmXW0fX-fPGFFTOBWrAyBJqxT7TbwtBty8B578aQOclH5MgpCl5R3yhilPDCHo9T7CHKZLuh3FI-5Wu3b3507sOirPYdaEVNRbHqTlGYn1h7GxZPHQ1KSA7asRTGLJGD7sBGTqG_sWRgA1uOjdFqmU4xzICmdK_UfdBuhGgZDw1PIAHaVTaxdoD38klnpHqV_RK1ssxl3dE4NsI3tlIe_6f3Xj5N7L9NZftBn4ftQ">
      <div aria-hidden="true" className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 overflow-hidden">
          <img alt="" className="absolute h-[206.87%] left-0 max-w-none top-[-53.44%] w-full" src={imgAb6AXuAkF3E40IeKenxTx1VAoMs0VsNuDUteD38OzmXw0FXFPgfftobWrAyBJqxT7TbwtBty8B578AQOclH5MgpCl5R3YhilPdcHo9T7ChkzLuh3Fi5Wu3B3507SOirPYdaEvnRbHqTlGYn1H7GxZphq1Ksa7AsRtgljgd7SBgTqGSWRgA1UOjdFqmU4XzICmdKUfdBuhGgZDw1PiaHaVTaxdoD38KlnpHqVRk1Ssxl3DE4NsI3TlIe6F3Xj5N7L9NZftBn4FtQ} />
        </div>
        <div className="absolute bg-white inset-0 mix-blend-saturation" />
      </div>
    </div>
  );
}

function OverlayOverlayBlur() {
  return (
    <div className="backdrop-blur-[6px] bg-[rgba(235,235,235,0.1)] content-stretch flex flex-col items-start px-[16px] py-[4px] relative rounded-[12px] shrink-0" data-name="Overlay+OverlayBlur">
      <div className="flex flex-col font-['Manrope:Bold',sans-serif] font-bold h-[20px] justify-center leading-[0] relative shrink-0 text-[#ffd308] text-[14px] tracking-[1.4px] uppercase w-[144.55px]">
        <p className="leading-[20px]">EXECUTIVE CLASS</p>
      </div>
    </div>
  );
}

function Margin1() {
  return (
    <div className="content-stretch flex flex-col items-start pb-[16px] relative shrink-0" data-name="Margin">
      <OverlayOverlayBlur />
    </div>
  );
}

function MarginAlignFlexStart() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Margin:align-flex-start">
      <Margin1 />
    </div>
  );
}

function Heading6() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Heading 4">
      <div className="flex flex-col font-['Manrope:Bold',sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[30px] text-white w-full">
        <p className="leading-[36px]">The Madrid Business Suite</p>
      </div>
    </div>
  );
}

function Background() {
  return (
    <div className="absolute bg-gradient-to-t content-stretch flex flex-col from-[rgba(0,0,0,0.8)] inset-[0_0.01px_0_0] items-start justify-end p-[48px] to-[rgba(0,0,0,0)]" data-name="Background">
      <MarginAlignFlexStart />
      <Heading6 />
    </div>
  );
}

function Container57() {
  return (
    <div className="col-[1/span_8] content-stretch flex flex-col items-start justify-center justify-self-stretch overflow-clip relative rounded-[8px] row-1 self-stretch shrink-0" data-name="Container">
      <Ab6AXuAkF3E40IeKenxTx1VAoMs0VsNuDUteD38OzmXw0FXFPgfftobWrAyBJqxT7TbwtBty8B578AQOclH5MgpCl5R3YhilPdcHo9T7ChkzLuh3Fi5Wu3B3507SOirPYdaEvnRbHqTlGYn1H7GxZphq1Ksa7AsRtgljgd7SBgTqGSWRgA1UOjdFqmU4XzICmdKUfdBuhGgZDw1PiaHaVTaxdoD38KlnpHqVRk1Ssxl3DE4NsI3TlIe6F3Xj5N7L9NZftBn4FtQ />
      <Background />
    </div>
  );
}

function AdBb0Ug7Pwj1Md8RuuHnTdDxUzi4TbI74Gxc5XDsQcr75PmS5Rg1Uufj7U1C6K9UEjKd0BLuiPoQjaBbkMfwjI6ZVBsgL80IuPiR39VRhEfBciu7QiShmfQeHEd5ZeTGyV7LdxYnIj7VMg1FaAlxmSxHnFyh1HpcUly4BsgleZsqn37AOie0Gap080GrIvcX0AxpoyG45UTfoNdEhSgSlGhXCpp9XIysoVzsFwFskQCajEk8Cc8Eb22LYbA() {
  return (
    <div className="relative size-full" data-name="ADBb0ug7PWJ1md8RuuHNTdDxUzi4tbI74gxc5XDsQCR-75-PmS5Rg1Uufj7u1c6k9uEJKd0BLuiPOQjaBBKMfwjI6zVBsgL80iuPiR39VRhEfBciu7QIShmfQeHEd5zeTGyV7LDXYnIj7vMG1FaALXMSxHNFyh1HpcUly4bsgleZSQN37aOie0gap-080GRIvcX0AxpoyG45UTfoNDEhSGSlGhXCpp9xIYSOVzsFWFskQCajEk8CC8Eb22lYbA">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <img alt="" className="absolute h-[110.38%] left-[-5%] max-w-none top-[-5.19%] w-[110%]" src={imgAdBb0Ug7Pwj1Md8RuuHnTdDxUzi4TbI74Gxc5XDsQcr75PmS5Rg1Uufj7U1C6K9UEjKd0BLuiPoQjaBbkMfwjI6ZVBsgL80IuPiR39VRhEfBciu7QiShmfQeHEd5ZeTGyV7LdxYnIj7VMg1FaAlxmSxHnFyh1HpcUly4BsgleZsqn37AOie0Gap080GrIvcX0AxpoyG45UTfoNdEhSgSlGhXCpp9XIysoVzsFwFskQCajEk8Cc8Eb22LYbA} />
      </div>
    </div>
  );
}

function Heading7() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Heading 4">
      <div className="flex flex-col font-['Manrope:Bold',sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[20px] text-white w-full">
        <p className="leading-[28px]">Any time, Anywhere</p>
      </div>
    </div>
  );
}

function Container59() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center leading-[0] not-italic relative shrink-0 text-[#adaaaa] text-[14px] w-full">
        <p className="leading-[20px]">Full electric, zero compromise.</p>
      </div>
    </div>
  );
}

function Background1() {
  return (
    <div className="absolute bg-gradient-to-t content-stretch flex flex-col from-[rgba(0,0,0,0.8)] inset-[0_-0.01px_0_0] items-start justify-end p-[32px] to-[rgba(0,0,0,0)]" data-name="Background">
      <Heading7 />
      <Container59 />
    </div>
  );
}

function Container58() {
  return (
    <div className="col-[9/span_4] justify-self-stretch overflow-clip relative rounded-[8px] row-1 self-stretch shrink-0" data-name="Container">
      <div className="absolute flex inset-[-19.4px_-19.48px_-19.4px_-19.47px] items-center justify-center" style={{ containerType: "size" }}>
        <div className="flex-none h-[100cqh] w-[100cqw]">
          <AdBb0Ug7Pwj1Md8RuuHnTdDxUzi4TbI74Gxc5XDsQcr75PmS5Rg1Uufj7U1C6K9UEjKd0BLuiPoQjaBbkMfwjI6ZVBsgL80IuPiR39VRhEfBciu7QiShmfQeHEd5ZeTGyV7LdxYnIj7VMg1FaAlxmSxHnFyh1HpcUly4BsgleZsqn37AOie0Gap080GrIvcX0AxpoyG45UTfoNdEhSgSlGhXCpp9XIysoVzsFwFskQCajEk8Cc8Eb22LYbA />
        </div>
      </div>
      <Background1 />
    </div>
  );
}

function Ab6AXuC7WrDBiUWiA4IioVoyYjlc60LUDGysXjnULWrdNaNg3DAgKycJXkKboLMrvXTiHj1ERvHuQQzhoUNlMu0RVdlKFf1Zxl9W4Lgw631Pzxrdn7DkRDoXDmLaXaItKjscqwYaFp4AS3Bn1T0Q2YHzeliaItfYSJoLR7TdPkj57GTfOsAiwVlkkQc5X8UkfXvhFiGdUuAfBIkLce7Ji9D3A0Zhu9U1JGqAzdpt8CqLlalNyMjOc0WJcCmJNiR6Y4BIiuxHl() {
  return (
    <div className="flex-[1_0_0] min-h-px relative w-full" data-name="AB6AXuC7wrDBi-UWiA4iioVoy-YJLC60lU_DGysXjn-uLWrdNaNg3DAgKycJXkKboLMrvXTiHj1ERvHuQQzhoUNlMu0RVdlKFf1zxl9W4lgw631pzxrdn7dkR-doXDmLaXAItKjscqwYaFp4aS3Bn1t0Q2YHzeliaItfY-sJoL_R7TdPKJ57GTfOs-aiwVlkkQC5X8UkfXVHFiGdUUAfBIkLCE7ji9d3a0zhu9u1_jGqAZDPT8CqLLALNyMJOc0WJcCmJNiR6y4bIiuxHl0">
      <div aria-hidden="true" className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 overflow-hidden">
          <img alt="" className="absolute h-[100.34%] left-0 max-w-none top-[-0.17%] w-full" src={imgAb6AXuC7WrDBiUWiA4IioVoyYjlc60LUDGysXjnULWrdNaNg3DAgKycJXkKboLMrvXTiHj1ERvHuQQzhoUNlMu0RVdlKFf1Zxl9W4Lgw631Pzxrdn7DkRDoXDmLaXaItKjscqwYaFp4AS3Bn1T0Q2YHzeliaItfYSJoLR7TdPkj57GTfOsAiwVlkkQc5X8UkfXvhFiGdUuAfBIkLce7Ji9D3A0Zhu9U1JGqAzdpt8CqLlalNyMjOc0WJcCmJNiR6Y4BIiuxHl0} />
        </div>
        <div className="absolute bg-white inset-0 mix-blend-saturation" />
      </div>
    </div>
  );
}

function Heading8() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Heading 4">
      <div className="flex flex-col font-['Manrope:Bold',sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[20px] text-white w-full">
        <p className="leading-[28px]">Fleet Collective</p>
      </div>
    </div>
  );
}

function Container61() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center leading-[0] not-italic relative shrink-0 text-[#adaaaa] text-[14px] w-full">
        <p className="leading-[20px]">For elite groups and teams.</p>
      </div>
    </div>
  );
}

function Background2() {
  return (
    <div className="absolute bg-gradient-to-t content-stretch flex flex-col from-[rgba(0,0,0,0.8)] inset-0 items-start justify-end p-[32px] to-[rgba(0,0,0,0)]" data-name="Background">
      <Heading8 />
      <Container61 />
    </div>
  );
}

function Container60() {
  return (
    <div className="col-[1/span_4] content-stretch flex flex-col items-start justify-center justify-self-stretch overflow-clip relative rounded-[8px] row-2 self-stretch shrink-0" data-name="Container">
      <Ab6AXuC7WrDBiUWiA4IioVoyYjlc60LUDGysXjnULWrdNaNg3DAgKycJXkKboLMrvXTiHj1ERvHuQQzhoUNlMu0RVdlKFf1Zxl9W4Lgw631Pzxrdn7DkRDoXDmLaXaItKjscqwYaFp4AS3Bn1T0Q2YHzeliaItfYSJoLR7TdPkj57GTfOsAiwVlkkQc5X8UkfXvhFiGdUuAfBIkLce7Ji9D3A0Zhu9U1JGqAzdpt8CqLlalNyMjOc0WJcCmJNiR6Y4BIiuxHl />
      <Background2 />
    </div>
  );
}

function Ab6AXuDpOxsOoBdObKxnoCreLgMxdKf0KwRp4XNkgecWAbp96XcG3SeMrbkzcWcy0TYvl0Vcl9Qc3CJaGmjEcj0DnDixN2QHtBmV2SFeQv1Fggx7HnR40CMwRMuGurLvHwuz91GAlw34HygrQoTEquMkhm7BYoJtIaCtRybbqdSJTpN5FBctACrPwTmpiJ8GSoIuxKNd0OKlH1JtyJzuzFoJ4XCw6ZKXbn5W9AM9QA1Yf4MyyUp2WdCuTn2AUxgBDhOoWx9Gk() {
  return (
    <div className="flex-[1_0_0] min-h-px relative w-full" data-name="AB6AXuDpOXSOoBd-obKxnoCreLgMXDKf0_KwRp4XNkgecWAbp96XcG3seMRBKZCWcy0TYvl0VCL9QC3cJAGmjEcj0dnDixN2qHTBmV2sFeQV1fggx7hnR40CMwRMuGurLVHwuz91GAlw34HYGRQoTEquMkhm7BYoJtIACtRYBBQD-sJ-tpN5F_Bct_aCr_pwTmpiJ8G_SOIuxKNd0OKlH1JtyJZUZFoJ4XCw6Z_KXbn5w9aM9Q-a1yf4myyUP2wdCuTN2aUxgBDhOOWx9Gk">
      <div aria-hidden="true" className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 overflow-hidden">
          <img alt="" className="absolute h-[206.87%] left-0 max-w-none top-[-53.44%] w-full" src={imgAb6AXuDpOxsOoBdObKxnoCreLgMxdKf0KwRp4XNkgecWAbp96XcG3SeMrbkzcWcy0TYvl0Vcl9Qc3CJaGmjEcj0DnDixN2QHtBmV2SFeQv1Fggx7HnR40CMwRMuGurLvHwuz91GAlw34HygrQoTEquMkhm7BYoJtIaCtRybbqdSJTpN5FBctACrPwTmpiJ8GSoIuxKNd0OKlH1JtyJzuzFoJ4XCw6ZKXbn5W9AM9QA1Yf4MyyUp2WdCuTn2AUxgBDhOoWx9Gk} />
        </div>
        <div className="absolute bg-white inset-0 mix-blend-saturation" />
      </div>
    </div>
  );
}

function Heading9() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Heading 4">
      <div className="flex flex-col font-['Manrope:Bold',sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[30px] text-white w-full">
        <p className="leading-[36px]">The Night Pulse</p>
      </div>
    </div>
  );
}

function Background3() {
  return (
    <div className="absolute bg-gradient-to-t content-stretch flex flex-col from-[rgba(0,0,0,0.8)] inset-0 items-start justify-end p-[48px] to-[rgba(0,0,0,0)]" data-name="Background">
      <Heading9 />
    </div>
  );
}

function Container62() {
  return (
    <div className="col-[5/span_8] content-stretch flex flex-col items-start justify-center justify-self-stretch overflow-clip relative rounded-[8px] row-2 self-stretch shrink-0" data-name="Container">
      <Ab6AXuDpOxsOoBdObKxnoCreLgMxdKf0KwRp4XNkgecWAbp96XcG3SeMrbkzcWcy0TYvl0Vcl9Qc3CJaGmjEcj0DnDixN2QHtBmV2SFeQv1Fggx7HnR40CMwRMuGurLvHwuz91GAlw34HygrQoTEquMkhm7BYoJtIaCtRybbqdSJTpN5FBctACrPwTmpiJ8GSoIuxKNd0OKlH1JtyJzuzFoJ4XCw6ZKXbn5W9AM9QA1Yf4MyyUp2WdCuTn2AUxgBDhOoWx9Gk />
      <Background3 />
    </div>
  );
}

function Container56() {
  return (
    <div className="gap-x-[24px] gap-y-[24px] grid grid-cols-[repeat(12,minmax(0,1fr))] grid-rows-[__388px_388px] h-[800px] relative shrink-0 w-full" data-name="Container">
      <Container57 />
      <Container58 />
      <Container60 />
      <Container62 />
    </div>
  );
}

function Container52() {
  return (
    <div className="max-w-[1440px] relative shrink-0 w-full" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[64px] items-start max-w-[inherit] relative size-full">
        <Container53 />
        <Container56 />
      </div>
    </div>
  );
}

function SectionFleetShowcaseBentoGrid() {
  return (
    <div className="absolute bg-[#0e0e0e] content-stretch flex flex-col items-start left-0 pb-[128px] pt-[129px] px-[32px] right-0 top-[5064px]" data-name="Section - Fleet Showcase (Bento Grid)">
      <div aria-hidden="true" className="absolute border-[rgba(255,255,255,0.05)] border-solid border-t inset-0 pointer-events-none" />
      <Container52 />
    </div>
  );
}

function Container64() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
      <div className="flex flex-col font-['Manrope:ExtraBold',sans-serif] font-extrabold h-[32px] justify-center leading-[0] relative shrink-0 text-[#ffd308] text-[24px] tracking-[-1.2px] uppercase w-[129.3px]">
        <p className="leading-[32px]">MADRILEÑO</p>
      </div>
    </div>
  );
}

function Link6() {
  return (
    <div className="content-stretch flex flex-col items-start pb-[6px] relative shrink-0" data-name="Link">
      <div aria-hidden="true" className="absolute border-[#ffd308] border-b-2 border-solid inset-0 pointer-events-none" />
      <div className="flex flex-col font-['Manrope:Bold',sans-serif] font-bold h-[24px] justify-center leading-[0] relative shrink-0 text-[#ffd308] text-[16px] tracking-[-0.8px] w-[31.36px]">
        <p className="leading-[24px]">Ride</p>
      </div>
    </div>
  );
}

function Link7() {
  return (
    <div className="content-stretch flex flex-col items-start px-[12px] py-[4px] relative rounded-[2px] shrink-0" data-name="Link">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[24px] justify-center leading-[0] not-italic relative shrink-0 text-[#a3a3a3] text-[16px] w-[53.3px]">
        <p className="leading-[24px]">Airport</p>
      </div>
    </div>
  );
}

function Link8() {
  return (
    <div className="content-stretch flex flex-col items-start px-[12px] py-[4px] relative rounded-[2px] shrink-0" data-name="Link">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[24px] justify-center leading-[0] not-italic relative shrink-0 text-[#a3a3a3] text-[16px] w-[69.05px]">
        <p className="leading-[24px]">Business</p>
      </div>
    </div>
  );
}

function Link9() {
  return (
    <div className="content-stretch flex flex-col items-start px-[12px] py-[4px] relative rounded-[2px] shrink-0" data-name="Link">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[24px] justify-center leading-[0] not-italic relative shrink-0 text-[#a3a3a3] text-[16px] w-[37.7px]">
        <p className="leading-[24px]">Fleet</p>
      </div>
    </div>
  );
}

function Link10() {
  return (
    <div className="content-stretch flex flex-col items-start px-[12px] py-[4px] relative rounded-[2px] shrink-0" data-name="Link">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[24px] justify-center leading-[0] not-italic relative shrink-0 text-[#a3a3a3] text-[16px] w-[60.31px]">
        <p className="leading-[24px]">Contact</p>
      </div>
    </div>
  );
}

function Container65() {
  return (
    <div className="content-stretch flex gap-[32px] items-center relative shrink-0" data-name="Container">
      <Link6 />
      <Link7 />
      <Link8 />
      <Link9 />
      <Link10 />
    </div>
  );
}

function Button4() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center px-[16px] relative shrink-0" data-name="Button">
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[24px] justify-center leading-[0] not-italic relative shrink-0 text-[#a3a3a3] text-[16px] text-center w-[42.28px]">
        <p className="leading-[24px]">Login</p>
      </div>
    </div>
  );
}

function Button5() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center px-[24px] py-[10px] relative rounded-[4px] shrink-0" style={{ backgroundImage: "linear-gradient(135deg, rgb(255, 228, 139) 0%, rgb(255, 211, 8) 100%)" }} data-name="Button">
      <div className="flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[24px] justify-center leading-[0] not-italic relative shrink-0 text-[#5a4900] text-[16px] text-center w-[78.27px]">
        <p className="leading-[24px]">Book Now</p>
      </div>
    </div>
  );
}

function Container66() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0" data-name="Container">
      <Button4 />
      <Button5 />
    </div>
  );
}

function Container63() {
  return (
    <div className="flex-[1_0_0] max-w-[1440px] min-h-px relative w-full" data-name="Container">
      <div className="flex flex-row items-center max-w-[inherit] size-full">
        <div className="content-stretch flex items-center justify-between max-w-[inherit] px-[32px] relative size-full">
          <Container64 />
          <Container65 />
          <Container66 />
        </div>
      </div>
    </div>
  );
}

function TopNavBar() {
  return (
    <div className="absolute backdrop-blur-[6px] bg-[rgba(14,14,14,0.9)] content-stretch flex flex-col h-[80px] items-start justify-center left-0 top-0 w-[1280px]" data-name="TopNavBar">
      <Container63 />
    </div>
  );
}

export default function HtmlBody() {
  return (
    <div className="relative size-full" style={{ backgroundImage: "linear-gradient(90deg, rgb(14, 14, 14) 0%, rgb(14, 14, 14) 100%), linear-gradient(90deg, rgb(255, 255, 255) 0%, rgb(255, 255, 255) 100%)" }} data-name="Html → Body">
      <SectionKeyFeaturesTonalLayering />
      <Footer />
      <MainHeroSectionWithAsymmetricLayout />
      <ContactFormSection />
      <SectionFleetShowcaseBentoGrid />
      <TopNavBar />
    </div>
  );
}