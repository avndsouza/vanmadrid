import HtmlBody from "../imports/Html→Body-55-519";

export default function App() {
  return <HtmlBody />;
}
