# Design System Specification: Urban Velocity

## 1. Overview & Creative North Star
### The Creative North Star: "The Urban Pulse"
This design system moves beyond the utility of a standard taxi app to create a high-end, editorial experience reflecting the rhythm of Madrid. We are shifting away from the "yellow-cab-cliché" toward a sophisticated, dark-mode aesthetic that mirrors the city’s nightlife and professional elegance.

To break the "template" look, this system utilizes **Intentional Asymmetry** and **Tonal Depth**. By avoiding rigid grids and embracing overlapping elements—such as a typography-heavy headline bleeding into a floating car asset—we create a sense of motion and urgency. The experience should feel like a premium concierge service: efficient, urban, and authoritative.

---

## 2. Colors & Surface Architecture
The palette is rooted in high-contrast prestige. We use deep charcoals and blacks to ground the interface, while the vibrant yellow acts as a "laser-focused" guide for the user’s eye.

### The "No-Line" Rule
**Explicit Instruction:** Traditional 1px solid borders are strictly prohibited for sectioning. Boundaries must be defined solely through background color shifts. Use `surface-container-low` for secondary sections and `surface-container-highest` for high-priority interactive zones.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of luxury materials. 
- **Base Layer:** `surface` (#0e0e0e).
- **Secondary Sectioning:** `surface-container-low` (#131313).
- **Interactive Containers:** `surface-container` (#1a1a1a).
- **Elevated Items (Cards):** `surface-container-highest` (#262626).

### The "Glass & Gradient" Rule
To ensure the "Urban Pulse" vibe, floating elements (like map controls or booking summaries) must use **Glassmorphism**. Apply `surface-bright` at 60% opacity with a `20px` backdrop-blur. 
- **Signature Texture:** Use a subtle linear gradient from `primary` (#ffe48b) to `primary-container` (#ffd308) at a 135-degree angle for main CTAs to give them a metallic, automotive sheen.

---

## 3. Typography
The typography strategy pairs the technical precision of **Inter** with the architectural character of **Manrope**.

*   **Display & Headlines (Manrope):** These are our "Editorial Hooks." Use `display-lg` and `headline-lg` with tight letter-spacing (-0.02em) to evoke a sense of premium power.
*   **Body & Labels (Inter):** Reserved for high-speed legibility. Inter's tall x-height ensures that ride details and prices are readable at a glance in bright sun or low-light conditions.

**Hierarchy as Identity:** Use `headline-sm` in `primary` yellow to call out key destinations, while using `on-surface-variant` (#adaaaa) for secondary metadata to create a clear, sophisticated "information stack."

---

## 4. Elevation & Depth
We eschew the "material" shadow in favor of **Tonal Layering**.

*   **The Layering Principle:** A "Book Now" card should not have a shadow; instead, place it as a `surface-container-high` element on top of a `surface-container-low` background. The contrast in value creates a "soft lift."
*   **Ambient Shadows:** For map overlays only, use a "Tinted Ambient" shadow: `box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4)`. Never use pure black shadows; they feel "muddy."
*   **The Ghost Border Fallback:** If a UI element needs further definition against a complex background, use a **Ghost Border**: `outline-variant` (#484847) at 15% opacity.

---

## 5. Components

### Buttons: The Kinetic Engine
*   **Primary:** Background `primary-container` (#ffd308), text `on-primary-container` (#5a4900). Shape: `md` (0.375rem). Use the signature gradient for the "Confirm Ride" state.
*   **Secondary:** Background `transparent`, Ghost Border (15% opacity `outline`), text `primary`.
*   **Tertiary:** Text-only using `label-md`, `primary` color, all-caps with 0.05em tracking.

### Cards & Lists: The Streamlined Flow
*   **Forbid Dividers:** Do not use lines to separate "Eco," "Standard," or "Van" ride options. Instead, use a vertical padding of `1.5rem` and a background shift to `surface-container-low` on hover/selection.
*   **Selection Chips:** For "Now" vs "Scheduled" toggles. Use `full` (pill) roundedness. Selected state: `primary` background with `on-primary` text.

### Input Fields: Urban Precision
*   **Input Style:** `surface-container-high` background, `none` border, `sm` roundedness. 
*   **Focus State:** A 2px "Ghost Border" of `primary` yellow at 50% opacity.
*   **Error State:** Text uses `error` (#ff7351); the container background shifts to `error_container` at 10% opacity.

### Contextual Components
*   **The Route-Tracker:** A custom component using a `primary_dim` path with a `surface_bright` glowing dot.
*   **Price Badge:** A `tertiary_container` pill using `title-sm` typography to make the fare the most authoritative element on the screen.

---

## 6. Do's and Don'ts

### Do:
*   **Do** use asymmetrical margins (e.g., 24px left, 32px right) for hero text to create a modern, editorial look.
*   **Do** lean into high-contrast "Dark Mode" as the default; it reduces glare for drivers and looks premium for passengers.
*   **Do** use `primary` yellow sparingly. It is a functional tool for "Action" and "Attention," not a background color.

### Don't:
*   **Don't** use 100% opaque, high-contrast borders. It breaks the "Urban Pulse" flow and feels like a 2010s template.
*   **Don't** use standard "drop shadows." Only use tonal shifts or ultra-diffused ambient glows.
*   **Don't** use dividers. If two elements need separation, use the Spacing Scale (minimum 16px) or a background value change.